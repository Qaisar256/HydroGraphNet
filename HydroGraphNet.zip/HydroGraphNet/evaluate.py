import argparse,json
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from train import load_data,loader
from models.hydrographnet import HydroGraphNet
from utils.metrics import metrics
from utils.visualization import plot_predictions

def evaluate(checkpoint):
    ck=torch.load(checkpoint,map_location='cpu',weights_only=True); c=ck['config']; d=load_data(c); model=HydroGraphNet(c,ck['edges'],ck['mode']); model.load_state_dict(ck['state']); model.eval(); rows=[]; tau=ck['tau'];
    if not np.isclose(tau,float(d['tau'])): raise ValueError('Checkpoint and processed data threshold mismatch')
    with torch.no_grad():
        for x,q,y,idx in loader(d,2,c['batch_size']):
            p,l=model(x,q); prob=l.sigmoid();
            for b,i in enumerate(idx.tolist()):
                for j,s in enumerate(d['stations']):
                    if torch.isfinite(y[b,j]): rows.append(dict(date=d['dates'][i],station=s,observed=float(y[b,j]),predicted=float(p[b,j]),probability=float(prob[b,j]),threshold_alert=int(p[b,j]>tau),head_alert=int(prob[b,j]>=.5)))
    df=pd.DataFrame(rows); out=Path(checkpoint).parent; df.to_csv(out/'test_predictions.csv',index=False)
    def score(f): return metrics(f.observed.to_numpy(),f.predicted.to_numpy(),f.probability.to_numpy(),tau)
    result=dict(unit=c['unit'],threshold=tau,overall=score(df),per_station={str(s):score(f) for s,f in df.groupby('station')}); (out/'metrics.json').write_text(json.dumps(result,indent=2)); plot_predictions(df,out/'forecast.png',c['unit']); print(json.dumps(result,indent=2)); return result
if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--checkpoint',required=True); evaluate(p.parse_args().checkpoint)
