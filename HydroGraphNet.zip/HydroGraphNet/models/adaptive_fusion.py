import torch
from torch import nn
class AdaptiveFusion(nn.Module):
    def __init__(self,h):
        super().__init__(); self.gate=nn.Linear(2*h+2,h)
    def forward(self,t,g,q,mask,fixed=False):
        gamma=torch.full_like(t,.5) if fixed else torch.sigmoid(self.gate(torch.cat([t,g,q],dim=-1))); return torch.where(mask,gamma*t+(1-gamma)*g,t)
