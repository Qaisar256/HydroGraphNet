import torch
from torch import nn
from models.gru_encoder import GRUEncoder
from models.hierarchical_aggregation import HierarchicalAggregation
from models.adaptive_fusion import AdaptiveFusion
class HydroGraphNet(nn.Module):
    def __init__(self,c,edges,mode='full'):
        super().__init__(); h=c['hidden']; self.edges=edges; self.mode=mode; self.encoder=GRUEncoder(2*len(c['features']),h,c['layers'],c['dropout']); self.graph=HierarchicalAggregation(h,c['heads']); self.fusion=AdaptiveFusion(h); self.reg=nn.Sequential(nn.Linear(h,h),nn.ReLU(),nn.Linear(h,1),nn.Softplus()); self.alert=nn.Sequential(nn.Linear(h,h),nn.ReLU(),nn.Linear(h,1))
    def forward(self,x,q):
        t=self.encoder(x); z=t
        if self.edges:
            g=self.graph(t,torch.zeros_like(q) if self.mode=='no_discharge' else q,self.edges); mask=torch.tensor([any(b==i for a,b in self.edges) for i in range(t.shape[1])],device=t.device).view(1,-1,1); z=self.fusion(t,g,q,mask,self.mode=='no_fusion')
        return self.reg(z).squeeze(-1),self.alert(z).squeeze(-1)
