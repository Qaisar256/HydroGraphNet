import torch
from torch import nn
class GRUEncoder(nn.Module):
    def __init__(self,features,hidden,layers,dropout):
        super().__init__(); self.gru=nn.GRU(features,hidden,layers,batch_first=True,dropout=dropout if layers>1 else 0); self.norm=nn.LayerNorm(hidden)
    def forward(self,x):
        b,n,l,f=x.shape; _,h=self.gru(x.reshape(b*n,l,f)); return self.norm(h[-1].reshape(b,n,-1))
