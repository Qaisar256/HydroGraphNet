import torch
from torch import nn
class AttentionLayer(nn.Module):
    def __init__(self,h,heads):
        super().__init__(); self.src=nn.Linear(h,h); self.dst=nn.Linear(h,h); self.edge=nn.Linear(2,h); self.score=nn.Linear(h,heads,bias=False); self.msg=nn.Linear(h,h); self.self_map=nn.Linear(h,h); self.norm=nn.LayerNorm(h)
    def forward(self,z,q,edges):
        result=[]
        for i in range(z.shape[1]):
            src=[a for a,b in edges if b==i]; local=z[:,i]; m=torch.zeros_like(local)
            if src:
                upstream=z[:,src]; scores=self.score(torch.tanh(self.src(upstream)+self.dst(local).unsqueeze(1)+self.edge(q[:,src]))); weights=scores.softmax(dim=1).mean(dim=-1); m=(weights.unsqueeze(-1)*self.msg(upstream)).sum(1)
            result.append(self.norm(torch.relu(self.self_map(local)+m)))
        return torch.stack(result,dim=1)
class HierarchicalAggregation(nn.Module):
    def __init__(self,h,heads):
        super().__init__(); self.layers=nn.ModuleList([AttentionLayer(h,heads) for _ in range(2)])
    def forward(self,z,q,edges):
        for layer in self.layers: z=layer(z,q,edges)
        return z
