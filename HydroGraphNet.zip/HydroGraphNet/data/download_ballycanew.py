"""Download original daily observations, not fitted distributions."""
import argparse
from pathlib import Path
import pandas as pd
from data.common import session,fetch,save_manifest

def download(ref='main'):
    root=Path('data/raw/ballycanew'); root.mkdir(parents=True,exist_ok=True)
    s=session(); manifest=[]; frames=[]
    # Resolve branch to immutable commit for reproducibility.
    r=s.get(f'https://api.github.com/repos/CamillaNegri/Ballycanew_Ptool/commits/{ref}',timeout=60); r.raise_for_status(); commit=r.json()['sha']
    for filename,col,out in [('Ballycanew_Turbidity_Sediments.csv','Turbidity[NTU]','turbidity'),('Ballycanew_discharge.csv','Qcumecs','discharge'),('Ballycanew_data.csv','TRP [mg/l]','trp')]:
        _,m=fetch(s,f'https://raw.githubusercontent.com/CamillaNegri/Ballycanew_Ptool/{commit}/data/{filename}',root/filename); manifest.append(m)
        f=pd.read_csv(root/filename,encoding='utf-8-sig'); f.columns=f.columns.str.strip(); f['date']=pd.to_datetime(f['Date'],format='%d/%m/%Y',errors='raise'); f[out]=pd.to_numeric(f[col],errors='coerce'); frames.append(f.set_index('date')[[out]])
    df=pd.concat(frames,axis=1).sort_index(); df['station']='Ballycanew'; df.to_csv(root/'observations.csv'); save_manifest(root/'manifest.json',dict(commit=commit,files=manifest,discharge_unit='source Qcumecs; physical unit not independently established',turbidity_unit='NTU')); print(df.count())
if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--ref',default='main'); download(p.parse_args().ref)
