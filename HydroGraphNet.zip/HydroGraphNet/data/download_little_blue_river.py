"""Retrieve USGS daily mean observations via OGC API; never equate FNU and NTU."""
import argparse, os
from pathlib import Path
import pandas as pd
import yaml
from data.common import session,fetch,save_manifest

API='https://api.waterdata.usgs.gov/ogcapi/v0/collections/daily/items'
DOI='https://doi.org/10.5066/F77W6B4Z'

def download(config):
    c=yaml.safe_load(Path(config).read_text()); root=Path('data/raw/little_blue_river'); root.mkdir(parents=True,exist_ok=True); s=session(); manifest=[]; frames=[]
    if os.getenv('USGS_API_KEY'): s.headers['X-Api-Key']=os.environ['USGS_API_KEY']
    for station in c['stations']:
        for code,feature in [('63680','turbidity'),('00060','discharge')]:
            url=API; params={'f':'json','monitoring_location_id':'USGS-'+station,'parameter_code':code,'statistic_id':'00003','time':c['start']+'/'+c['end'],'limit':10000}; rows=[]; page=0; seen=set()
            while url:
                r,m=fetch(s,url,root/f'{station}_{code}_{page}.json',params); manifest.append(m); js=r.json(); rows.extend(x['properties'] for x in js['features']); next_url=next((x['href'] for x in js.get('links',[]) if x.get('rel')=='next'),None)
                if next_url in seen: raise ValueError('Repeated pagination link')
                seen.add(next_url); url=next_url; params=None; page+=1
            if not rows: print(f'No data: {station} {code}'); continue
            f=pd.DataFrame(rows); f['date']=pd.to_datetime(f['time'].str[:10]); f['value']=pd.to_numeric(f['value'],errors='coerce'); f=f.loc[f.value.ge(0)].copy()
            # Exclude provisional or explicitly estimated observations when identifiable.
            for key in ['approval_status','qualifier','qualifiers']:
                if key in f: f=f.loc[~f[key].astype(str).str.contains(r'provisional|estimated|\bP\b|\bE\b',case=False,regex=True)]
            if f['date'].duplicated().any(): raise ValueError(f'Multiple daily series for {station} {code}; audit raw JSON before choosing one')
            f['station']=station; f['feature']=feature; frames.append(f[['date','station','feature','value']])
    if not frames: raise RuntimeError('No USGS observations returned')
    df=pd.concat(frames).pivot(index=['date','station'],columns='feature',values='value').reset_index(); df=df.reindex(columns=['date','station','turbidity','discharge']); df['discharge']*=0.028316846592; df.to_csv(root/'observations.csv',index=False)
    save_manifest(root/'manifest.json',dict(files=manifest,reference_release=DOI,source='USGS daily API, not identical to DOI archive',turbidity_unit='FNU',discharge_unit='m3/s',quality_policy='exclude explicit estimated/provisional flags when exposed')); print(df.groupby('station').count())
if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--config',default='config/little_blue_river_config.yaml'); download(p.parse_args().config)
