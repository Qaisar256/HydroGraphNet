"""Causal windows. Split by target date; fit statistics only before train cutoff."""
import argparse,json
from pathlib import Path
import numpy as np
import pandas as pd
import yaml

def prepare(c):
    name=c['name']; p=Path('data/raw')/name/'observations.csv'; f=pd.read_csv(p,dtype={'station':str},parse_dates=['date']); dates=pd.date_range(c['start'],c['end']); stations=c['stations']; features=c['features']; grid=pd.MultiIndex.from_product([dates,stations],names=['date','station']); f=f.set_index(['date','station']).reindex(grid)
    raw=f[features].apply(pd.to_numeric,errors='coerce').to_numpy().reshape(len(dates),len(stations),len(features)); raw[~np.isfinite(raw)|(raw<0)]=np.nan
    train=dates<=pd.Timestamp(c['train_end']); train_raw=raw[train]; valid=np.isfinite(raw); overlap=(valid[:,:,0]&valid[:,:,1]); audit={s:{'turbidity':int(valid[:,i,0].sum()),'discharge':int(valid[:,i,1].sum()),'overlap':int(overlap[:,i].sum()),'train_overlap':int(overlap[train,i].sum())} for i,s in enumerate(stations)}
    out=Path('data/processed')/name; out.mkdir(parents=True,exist_ok=True); (out/'coverage.json').write_text(json.dumps(audit,indent=2)); print(audit)
    if len(stations)>1 and any(v['train_overlap']<c.get('minimum_overlap',30) for v in audit.values()): raise ValueError('Insufficient verified station coverage; review coverage.json and revise station/edge configuration explicitly.')
    mu=np.nanmean(train_raw,axis=(0,1)); sd=np.nanstd(train_raw,axis=(0,1));
    if not np.isfinite(mu).all(): raise ValueError('A feature has no training observations')
    sd=np.where(sd>0,sd,1); x=np.concatenate([np.where(valid,(raw-mu)/sd,0),valid.astype(float)],axis=-1).astype('float32'); q=np.stack([np.log1p(np.where(valid[:,:,1],raw[:,:,1],0)),valid[:,:,1]],axis=-1).astype('float32'); y=raw[:,:,0].astype('float32'); L=c['lookback']; padded=np.pad(x,((L,0),(0,0),(0,0))); X=np.stack([padded[i:i+L] for i in range(len(dates))]).transpose(0,2,1,3); Q=np.concatenate([np.zeros_like(q[:1]),q[:-1]]); split=np.where(train,0,np.where(dates<=pd.Timestamp(c['val_end']),1,2)); eligible=np.isfinite(y); eligible[0]=False; y[~eligible]=np.nan; tau=float(np.nanquantile(y[train],.75)); print('Target counts:',[int(eligible[split==i].sum()) for i in range(3)],'threshold:',tau)
    np.savez_compressed(out/'dataset.npz',X=X,Q=Q,y=y,split=split,dates=dates.strftime('%Y-%m-%d').to_numpy(dtype=str),stations=np.array(stations),tau=tau,mu=mu,sd=sd,latest_x=x[-L:].transpose(1,0,2),latest_q=q[-1]); return out/'dataset.npz'
if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--config',required=True); prepare(yaml.safe_load(Path(p.parse_args().config).read_text()))
