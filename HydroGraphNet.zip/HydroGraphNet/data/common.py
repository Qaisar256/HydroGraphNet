import hashlib, json, datetime
from pathlib import Path
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

def session():
    s=requests.Session()
    s.mount('https://',HTTPAdapter(max_retries=Retry(total=4,backoff_factor=1,status_forcelist=[429,500,502,503,504])))
    return s

def fetch(s,url,path,params=None):
    r=s.get(url,params=params,timeout=120); r.raise_for_status()
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True); path.write_bytes(r.content)
    return r,dict(url=r.url, file=str(path),sha256=hashlib.sha256(r.content).hexdigest(), retrieved_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())

def save_manifest(path,records):
    Path(path).write_text(json.dumps(records,indent=2))
