from setuptools import setup, find_packages
from pathlib import Path
setup(name='hydrographnet', version='0.1.0', packages=find_packages(),
      python_requires='>=3.10', install_requires=Path(__file__).with_name('requirements.txt').read_text().splitlines())
