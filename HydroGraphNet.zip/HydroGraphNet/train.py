"""Train with masked MAE + auxiliary BCE; select by validation MAE only."""
import argparse, random, json
from pathlib import Path
import numpy as np
import torch
from torch.utils.data import DataLoader,TensorDataset
import yaml
from models.hydrographnet import HydroGraphNet
from utils.graph_utils import graph_edges

MODES=['full','gru','no_edges','shuffle','no_discharge','no_fusion']
def load_data(c):
    return np.load(Path('data/processed')/c['name']/'dataset.npz',allow_pickle=False)
def loader(d,part,batch,shuffle=False):
    idx=np.flatnonzero((d['split']==part)&np.isfinite(d['y']).any(axis=1));
    if not len(idx): raise ValueError(f'Empty partition {part}')
    return DataLoader(TensorDataset(*(torch.from_numpy(d[k][idx]) for k in ['X','Q','y']),torch.from_numpy(idx)),batch_size=batch,shuffle=shuffle)
def train(c,mode='full',output=None):
    seed=c['seed']; random.seed(seed); np.random.seed(seed); torch.manual_seed(seed); torch.use_deterministic_algorithms(True,warn_only=True); device=torch.device('cuda' if torch.cuda.is_available() else 'cpu'); d=load_data(c); tau=float(d['tau']); edges=graph_edges(c,mode); model=HydroGraphNet(c,edges,mode).to(device); opt=torch.optim.AdamW(model.parameters(),lr=c['lr'],weight_decay=c['weight_decay']); best=float('inf'); wait=0; history=[]; out=Path(output or f'outputs/{c["name"]}/{mode}'); out.mkdir(parents=True,exist_ok=True)
    tr=loader(d,0,c['batch_size'],True); va=loader(d,1,c['batch_size']);
    for epoch in range(c['epochs']):
        model.train(); total=0.; count=0
        for x,q,y,_ in tr:
            x,q,y=[v.to(device) for v in (x,q,y)]; valid=torch.isfinite(y); pred,logit=model(x,q); loss=(pred[valid]-y[valid]).abs().mean()+c['alert_weight']*torch.nn.functional.binary_cross_entropy_with_logits(logit[valid],(y[valid]>tau).float()); opt.zero_grad(); loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(),5.); opt.step(); total+=loss.item()*valid.sum().item(); count+=valid.sum().item()
        model.eval(); err=0.; n=0
        with torch.no_grad():
            for x,q,y,_ in va:
                x,q,y=[v.to(device) for v in (x,q,y)]; valid=torch.isfinite(y); pred,_=model(x,q); err+=(pred[valid]-y[valid]).abs().sum().item(); n+=valid.sum().item()
        score=err/n; record=dict(epoch=epoch+1,training_loss=total/count,validation_MAE=score); history.append(record); print(record)
        if score<best:
            best=score; wait=0; torch.save(dict(state=model.state_dict(),config=c,edges=edges,mode=mode,tau=tau),out/'best.pt')
        else:
            wait+=1
            if wait>=c['patience']: break
    (out/'history.json').write_text(json.dumps(history,indent=2)); return out/'best.pt'
if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--config',required=True); p.add_argument('--mode',choices=MODES,default='full'); p.add_argument('--output'); a=p.parse_args(); train(yaml.safe_load(Path(a.config).read_text()),a.mode,a.output)
