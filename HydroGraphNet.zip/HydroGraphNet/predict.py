"""Forecast the day immediately after the final input date in processed data."""
import argparse
from pathlib import Path
import pandas as pd
import torch
from train import load_data
from models.hydrographnet import HydroGraphNet

def predict(checkpoint):
    ck=torch.load(checkpoint,map_location='cpu',weights_only=True); c=ck['config']; d=load_data(c); model=HydroGraphNet(c,ck['edges'],ck['mode']); model.load_state_dict(ck['state']); model.eval()
    with torch.no_grad(): p,l=model(torch.from_numpy(d['latest_x'][None]),torch.from_numpy(d['latest_q'][None]));
    df=pd.DataFrame(dict(date=str((pd.Timestamp(str(d['dates'][-1]))+pd.Timedelta(days=1)).date()),station=d['stations'],prediction=p[0].numpy(),unit=c['unit'],alert_probability=l[0].sigmoid().numpy(),threshold_alert=(p[0]>ck['tau']).numpy())); df.to_csv(Path(checkpoint).parent/'next_day_prediction.csv',index=False); print(df.to_string(index=False)); return df
if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--checkpoint',required=True); predict(p.parse_args().checkpoint)
