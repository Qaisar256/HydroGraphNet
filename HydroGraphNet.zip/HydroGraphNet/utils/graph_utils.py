import numpy as np

def graph_edges(c,mode):
    edges=[tuple(e) for e in c['edges']]; n=len(c['stations'])
    if mode in ('gru','no_edges'): return []
    if edges and not c.get('graph_verified',False): raise ValueError('Audit reach connectivity and set graph_verified: true only after verification.')
    if any(a==b or min(a,b)<0 or max(a,b)>=n for a,b in edges) or len(set(edges))!=len(edges): raise ValueError('Invalid edges')
    if mode=='shuffle' and edges:
        rng=np.random.default_rng(c['seed']); candidates=[(a,b) for a in range(n) for b in range(n) if a!=b and (a,b) not in edges]; edges=[candidates[i] for i in rng.choice(len(candidates),len(edges),replace=False)]
    return edges
