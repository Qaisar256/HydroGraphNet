import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd

def plot_predictions(df,path,unit):
    fig,ax=plt.subplots(figsize=(11,4)); s=df.station.iloc[0]; f=df[df.station==s]; ax.plot(pd.to_datetime(f.date),f.observed,label='Observed'); ax.plot(pd.to_datetime(f.date),f.predicted,label='Forecast'); ax.set(ylabel=f'Turbidity ({unit})',title=str(s)); ax.legend(); fig.tight_layout(); fig.savefig(path,dpi=180); plt.close(fig)
