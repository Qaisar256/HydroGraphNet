import numpy as np
from sklearn.metrics import mean_absolute_error,mean_squared_error,accuracy_score,precision_score,recall_score,f1_score,roc_auc_score

def metrics(y,p,prob,tau):
    a=y>tau; b=prob>=.5; return dict(n=int(len(y)),MAE=float(mean_absolute_error(y,p)),RMSE=float(np.sqrt(mean_squared_error(y,p))),accuracy=float(accuracy_score(a,b)),precision=float(precision_score(a,b,zero_division=0)),recall=float(recall_score(a,b,zero_division=0)),F1=float(f1_score(a,b,zero_division=0)),ROC_AUC=float(roc_auc_score(a,prob)) if len(np.unique(a))==2 else None)
