import unittest
import torch
from models.hydrographnet import HydroGraphNet
class ModelTest(unittest.TestCase):
    def test_forward_backward(self):
        c=dict(hidden=8,layers=1,dropout=0.,heads=2,features=['turbidity','discharge']); x=torch.randn(3,7,7,4); q=torch.rand(3,7,2)
        for mode,edges in [('full',[(i,0) for i in range(1,6)]+[(0,6)]),('gru',[])]:
            m=HydroGraphNet(c,edges,mode); p,l=m(x,q); self.assertEqual(tuple(p.shape),(3,7)); self.assertTrue(torch.all(p>=0)); (p.mean()+l.mean()).backward(); self.assertTrue(any(v.grad is not None for v in m.parameters()))
if __name__=='__main__': unittest.main()
